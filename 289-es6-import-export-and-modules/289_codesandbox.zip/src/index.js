import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

// import pi, { doublePi, triplePi } from "./math";
import * as pi from "./math.js";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <div>
    <h1>Pi value</h1>
    {/* <ul>
      <li>{pi}</li>
      <li>{doublePi()}</li>
      <li>{triplePi()}</li>
    </ul> */}
    <ul>
      <li>{pi.default}</li>
      <li>{pi.doublePi()}</li>
      <li>{pi.triplePi()}</li>
    </ul>
  </div>
);
