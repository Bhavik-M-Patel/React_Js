import { createRoot } from "react-dom/client";
import ClassComponents from "./ClassComponents";
import FunctionalComponents from "./FunctionalComponents";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

export default function App() {
  root.render(<FunctionalComponents />);
}
