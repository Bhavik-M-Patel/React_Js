import { useState } from "react";

export default function App() {
  const [headingtext, setheadingtext] = useState("Hello");
  const [ismousedover, setmouseover] = useState(false);

  function handleclick() {
    setheadingtext("Submitted");
  }
  function handlemouseover() {
    setmouseover(true);
  }
  function handlemouseout() {
    setmouseover(false);
  }

  return (
    <div className="container">
      <h1>{headingtext}</h1>
      <input type="text" placeholder="What's your name?" />
      <button
        style={{ backgroundColor: ismousedover ? "black" : "white" }}
        onClick={handleclick}
        onMouseOver={handlemouseover}
        onMouseOut={handlemouseout}
      >
        Submit
      </button>
    </div>
  );
}
