import { useState } from "react";
import Styles from "../public/styles.css";

export default function App() {
  //   const [fName, setfName] = useState();
  //   const [lName, setlName] = useState();

  //   function updateFname(event) {
  //     const Fname = event.target.value;
  //     setfName(Fname);
  //   }
  //   function updateLname(event) {
  //     const Lname = event.target.value;
  //     setlName(Lname);
  //   }

  const [FullName, setFullName] = useState({
    fName: "",
    lName: "",
  });

  function handlechange(event) {
    const newValue = event.target.value;
    const inputName = event.target.name;

    setFullName((prevValue) => {
      if (inputName === "fName") {
        return {
          fName: newValue,
          lName: prevValue.lName,
        };
      } else if (inputName === "lName") {
        return {
          fName: prevValue.fName,
          lName: newValue,
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        {/* Hello! {fName} {lName} */}
        Hello! {FullName.fName} {FullName.lName}
      </h1>
      <form>
        <input
          name="fName"
          // onChange={updateFname}
          onChange={handlechange}
          placeholder="First Name"
          // value={fName}
          value={FullName.fName}
        />
        <input
          name="lName"
          // onChange={updateLname}
          onChange={handlechange}
          placeholder="Last Name"
          // value={lName}
          value={FullName.lName}
        />
        <button>Submit</button>
      </form>
    </div>
  );
}
