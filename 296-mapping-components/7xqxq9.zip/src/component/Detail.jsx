export default function Detail(props) {
  return <p className="info">{props.detailInfo}</p>;
}
