import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import styles from "./styles.css";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

function Card(props) {
  return (
    <div className="my-style">
      <h2>{props.name}</h2>
      <img src={props.img} alt="avatar_img" />
      <p>{props.tel}</p>
      <p>{props.email}</p>
    </div>
  );
}

root.render(
  <div>
    <h1>My Contacts</h1>
    <Card
      name="Beyonce"
      img="https://blackhistorywall.files.wordpress.com/2010/02/picture-device-independent-bitmap-119.jpg"
      tel="+123 456 789"
      email="b@beyonce.com"
    />
    <Card
      name="Jack Bauer"
      img="https://pbs.twimg.com/profile_images/625247595825246208/X3XLea04_400x400.jpg"
      tel="+7387384587"
      email="jack@nowhere.com"
    />
    <Card
      name="Bhavik"
      img="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-fmtoqPVclqoKV9FczSIbyX6EUNRVMbe-lDZO8leN8w&s"
      tel="+1234567890"
      email="bhavik@ss.com"
    />
  </div>
);
