import { StrictMode } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import styles from "../styles.css";

export default function App() {
  return (
    <div>
      <Header />
      <Note />
      <Footer />
    </div>
  );
}
