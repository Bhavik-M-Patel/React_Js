import { StrictMode } from "react";

export default function Header() {
  return (
    <div>
      <header>
        <h1>Keeper</h1>
      </header>
    </div>
  );
}
